program A5Q2
    implicit none
    integer::n,i,j
    real::h,a,b,T,D,Dr,er,D2,D3,D4,s1,s2,simb,simc

    real,dimension(0:12)::f,X
    open(10,file="A5Q2table1.txt")
    a=0
    b=3
    n=12

    write(*,*)"the x intervals"
    read(10,*)(x(i),i=0,n)
    write(*,*)(x(i),i=0,n)
    write(*,*)"the f(x)"

        read(10,*)(f(i),i=0,n)
     write(*,*)(f(i),i=0,n)
    T=0
    do i=1,n

        t=t+(0.5)*((f(i)+f(i-1))*(x(i)-x(i-1)))

    end do
     write(*,*)"assignment5 Q2 table 1a"
    write(*,*)"trapezoidal",T

    simb=0
    do i=1,n,2

      simb=simb+((x(i+1)-x(i-1))/6.0)*(f(i-1)+4*f(i)+f(i+1))
      write(*,*)i
    end do
    write(*,*)"assignment5 Q2 table1 b ",simb
    simc=0
    do i=1,n,3
        simc=simc+((x(i+2)-x(i-1))/8)*(f(i-1)+3*f(i)+3*f(i+1)+f(i+2))
    end do
    write(*,*)"assignment5 Q2 table1 c ",simc
end program
